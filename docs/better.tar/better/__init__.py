import os
better_theme_path = os.path.split(os.path.dirname(__file__))[0]
__version__ = '0.1.5'
